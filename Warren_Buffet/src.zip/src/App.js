import './App.css';
import RandomQuote from './Components/RandomQuote/RandomQuote';

function App() {
  return (
    <div>
      <RandomQuote/>
    </div>
  );
}

export default App;
