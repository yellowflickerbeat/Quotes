import React, { useEffect, useState } from "react";
import './RandomQuote.css'


const RandomQuote = () => {
    const warrenBuffettQuotes = [
        "The stock market is a device for transferring money from the impatient to the patient.",
        "Price is what you pay. Value is what you get.",
        "Someone is sitting in the shade today because someone planted a tree a long time ago.",
        "Risk comes from not knowing what you're doing.",
        "It’s only when the tide goes out that you learn who’s been swimming naked.",
        "The most important investment you can make is in yourself.",
        "Our favorite holding period is forever.",
        "The business schools reward difficult complex behavior more than simple behavior, but simple behavior is more effective.",
        "If you don’t find a way to make money while you sleep, you will work until you die.",
        "Time is the friend of the wonderful company, the enemy of the mediocre.",
        "In the business world, the rearview mirror is always clearer than the windshield.",
        "The best thing I did was to choose the right heroes.",
        "Only when the tide goes out do you discover who’s been swimming naked.",
        "I always knew I was going to be rich. I don’t think I ever doubted it for a minute.",
        "Our approach is very much profiting from lack of change rather than from change.",
        "The most important thing to do if you find yourself in a hole is to stop digging.",
        "I don’t look to jump over 7-foot bars; I look around for 1-foot bars that I can step over.",
        "You only have to do a very few things right in your life so long as you don’t do too many things wrong.",
        "It’s far better to buy a wonderful company at a fair price than a fair company at a wonderful price.",
        "The best investment you can make is in your own abilities. Anything you do to develop your own abilities is likely to be a good investment.",
        "If you’re not willing to own a stock for 10 years, don’t even think about owning it for 10 minutes.",
        "Our philosophy is to have the best managers. Then we let them run their businesses the way they want to.",
        "Chains of habit are too light to be felt until they are too heavy to be broken.",
        "Predicting rain doesn’t count. Building arks does.",
        "A public-opinion poll is no substitute for thought.",
        "In the business world, the rearview mirror is always clearer than the windshield.",
        "It’s good to learn from your mistakes. It’s better to learn from other people’s mistakes.",
        "We’re not as interested in the stock market as we are in buying good companies at reasonable prices.",
        "The stock market is filled with individuals who know the price of everything, but the value of nothing.",
        "The most important quality for an investor is temperament, not intellect.",
        "You’ve got to keep emotions in check when you’re investing.",
        "Look at market fluctuations as your friend rather than your enemy; profit from folly rather than participate in it.",
        "The difference between successful people and really successful people is that really successful people say no to almost everything.",
        "Do not take yearly results too seriously. Instead, focus on four or five-year averages.",
        "If you are not willing to own a stock for 10 years, do not even think about owning it for 10 minutes.",
        "Never depend on a single income. Make investment to create a second source.",
        "The most important investment you can make is in yourself.",
        "We don’t have to be smarter than the next guy. We just have to be smarter than the guy we were yesterday.",
        "There seems to be some perverse human characteristic that likes to make easy things difficult.",
        "If a business does well, the stock eventually follows.",
        "In investing, what is comfortable is rarely profitable.",
        "Risk comes from not knowing what you're doing.",
        "You want to be in the best business, with the best management, at the best price.",
        "The stock market is filled with people who know the price of everything but the value of nothing.",
        "I always try to invest in businesses that have sustainable competitive advantages.",
        "The most important thing to do if you find yourself in a hole is to stop digging.",
        "I never try to make money on the stock market, I try to buy good businesses and let them grow.",
        "You should invest in a business that even a fool can run, because someday a fool will.",
        "Don’t invest in a business you can’t understand.",
        "You only have to do a very few things right in your life so long as you don’t do too many things wrong.",
        "Only buy something that you’d be perfectly happy to hold if the market shut down for 10 years.",
        "The best thing I did was to choose the right heroes.",
        "The business schools reward difficult complex behavior more than simple behavior, but simple behavior is more effective.",
        "When we own portions of outstanding businesses with outstanding managements, our favorite holding period is forever.",
        "The investor of today does not profit from yesterday’s growth.",
        "When you combine ignorance and leverage, you get some pretty interesting results.",
        "I don’t look to jump over 7-foot bars; I look around for 1-foot bars that I can step over.",
        "I don’t care about the stock market’s short-term fluctuations. I care about the long-term prospects for the business.",
        "The most important thing is to make sure your business has a sustainable competitive advantage.",
        "Risk comes from not knowing what you’re doing.",
        "Don’t bet against America.",
        "The stock market is a device for transferring money from the impatient to the patient.",
        "A friend of mine said, 'You can’t go wrong with Coca-Cola.' He was right.",
        "I try to buy businesses that I think have durable competitive advantages.",
        "The best way to predict the future is to create it.",
        "You’re not a true investor unless you can live with short-term fluctuations in your portfolio.",
        "Our approach is very much profiting from lack of change rather than from change.",
        "The business schools reward difficult complex behavior more than simple behavior, but simple behavior is more effective.",
        "Do not take yearly results too seriously. Instead, focus on four or five-year averages.",
        "The stock market is filled with individuals who know the price of everything, but the value of nothing.",
        "In the end, it’s not how much money you make, it’s how much money you keep.",
        "You want to be in a business that has a wide moat and is protected from competition.",
        "The best investment you can make is in your own abilities. Anything you do to develop your own abilities is likely to be a good investment.",
        "The most important thing to do if you find yourself in a hole is to stop digging.",
        "I am a better investor because I am a businessman, and a better businessman because I am an investor.",
        "You have to have a lot of patience to be a successful investor.",
        "If you’re not willing to own a stock for 10 years, don’t even think about owning it for 10 minutes.",
        "I always try to invest in businesses that have sustainable competitive advantages.",
        "Don’t take yourself too seriously. It’s just money.",
        "If a business does well, the stock eventually follows.",
        "You only have to do a very few things right in your life so long as you don’t do too many things wrong.",
        "We don’t have to be smarter than the next guy. We just have to be smarter than the guy we were yesterday.",
        "Chains of habit are too light to be felt until they are too heavy to be broken.",
        "The stock market is filled with people who know the price of everything but the value of nothing.",
        "The business schools reward difficult complex behavior more than simple behavior, but simple behavior is more effective.",
        "I always knew I was going to be rich. I don’t think I ever doubted it for a minute.",
        "You can’t make a good deal with a bad person.",
        "You must learn to be fearful when others are greedy and greedy when others are fearful.",
        "Time is the friend of the wonderful company, the enemy of the mediocre.",
        "The most important quality for an investor is temperament, not intellect.",
        "Risk comes from not knowing what you're doing.",
        "The difference between successful people and really successful people is that really successful people say no to almost everything."
    ];
    

    const [quote, setQuote] = useState({
        text: warrenBuffettQuotes[Math.floor(Math.random() * warrenBuffettQuotes.length)],
        author: "Warren Buffett"
    });
    

    const getNewQuote = () => {
        setQuote({
            text: warrenBuffettQuotes[Math.floor(Math.random() * warrenBuffettQuotes.length)],
            author: "Warren Buffett"
        });
    };
    return (
        <div className='Container'>
            <div className="quote">{quote.text}</div>
            <div>
                <div className="line"></div><br></br>
                    <div className="author">{quote.author}</div>
            </div>
            <br></br>
            <center><button onClick={getNewQuote}>Change Quote</button></center>
            <footer>
                <p>© Made with ❤️ by Harsha</p>
            </footer>
        </div>


    );
};

export default RandomQuote